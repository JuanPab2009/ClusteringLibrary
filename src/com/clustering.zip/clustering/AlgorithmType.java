package com.clustering;

/**
 * Define los tipos de algoritmos disponibles.
 */
public enum AlgorithmType {
    KMEANS,
    HIERARCHICAL
}
